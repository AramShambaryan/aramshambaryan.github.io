import React from "react";
import { Link, Navigate, Route, Routes } from "react-router-dom";
import Register from "./Register";
import Login from "./Login";

const Auth = ({setToken}) => {
    return (
        <>
            <Link to="/register">Register</Link>
            <Link to="/login">Login</Link>
                
            <Routes>
                <Route path="/register" element={<Register setToken={setToken} />} />
                <Route path="/login" element={<Login setToken={setToken} />} />
            </Routes>
        </>
    );
}

export default Auth;