import React, { useState } from 'react';
import './App.css';
import { BrowserRouter, Route, Routes, Link, Navigate } from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import UserList from './pages/UserList';
import Header from './Header';
import Auth from './pages/Auth';


const App = () => {
    const [token, setToken] = useState('168|xpfjOdC5XPkVyj5OKcdPJUy1d5n6wYbRwJ0ckGGw3fc77627');
    //   const [token, setToken] = useState('');

    return (
        <BrowserRouter>
            <div>
                

                {token != '' ? <Header token={token} /> : <Auth setToken={setToken} />}
            </div>
        </BrowserRouter>
    );
};

export default App;