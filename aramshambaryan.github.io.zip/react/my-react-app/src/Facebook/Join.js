import React from "react";
import App from "./App";

function Join(){
    return(
        <div>
            
        </div>
    )
}

export default Join;