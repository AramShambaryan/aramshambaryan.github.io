for(let x = 1;x < 100 ;x++){
    console.log(x + " NO ");
}

/*let a = 10
let b = 7
let c = a+b
console.log(c)
let x = prompt("a+b" )
if (x==17){
    alert("ճիշտա")
}
if (x!=17){
    alert("sxala")
}*/