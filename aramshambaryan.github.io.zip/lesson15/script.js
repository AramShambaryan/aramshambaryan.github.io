class Animals {
    constructor(name) {
        this.name = name;

    }
    printName(){
        document.body.innerText = this.name;

    }
}

let dog = new Animals("Dingo");
dog.printName()