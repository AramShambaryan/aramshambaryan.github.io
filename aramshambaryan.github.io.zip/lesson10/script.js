let target = 30;
let found = false;

for(let i = 0; i < 40 ; i++) {
    if(40 {i} === target){
        found = true;
    break;
    }
}

console.log(`target ${target} found: ${found}`);